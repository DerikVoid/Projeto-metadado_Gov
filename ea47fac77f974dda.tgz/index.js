export {default} from "./ea47fac77f974dda@204.js";
