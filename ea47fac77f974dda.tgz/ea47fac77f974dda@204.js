function _1(md){return(
md`# Análise Visual de Contratações Públicas: itens, Categorias e performance de mercado
Este Documento tem a principal função de demosntrar as pricnipais contratações de serviços e compras realizadas pelo governo brasileiro no período de anos de 2021 a 2026 `
)}

function _embed(require){return(
require("vega-embed@5")
)}

function _3(){return(
"Embed: 5.1.3, Vega: 6.2.0, Vega-Lite: 6.4.3"
)}

function _4(md){return(
md`# 1 - Quantidade de contratações de serviços e de materiais pelo Governo
O gráfico aponta uma clara preferência pelas contratações de serviços em detrimento da aquisição de materiais. Essa liderança se consolida de forma expressiva no painel, registrando uma vantagem exata de 30 contratações a mais voltadas para o setor de prestação de serviços.`
)}

function _view1(embed){return(
embed({
  "$schema" : "https://vega.github.io/schema/vega-lite/v5.json",
  "title" : "Contratações de Serviços e materiais pelo governo",
  "data":{
    
    "url": "https://raw.githubusercontent.com/DerikVoid/Projeto-metadado_Gov/refs/heads/main/dadosGOV_tratados.csv",
      "format":{
        "type" : "csv"
      }
    
  },
  
 "width": 400,
 "height": 400,
  
  "mark": {
    "type": "arc",
    "innerRadius": 60
  },

  "encoding": {

    "theta": {
      "aggregate":"count",
      "field": "material_ou_servico",
      "type": "nominal"
    },

    "color": {
      "field": "material_ou_servico",
      "type": "nominal",
      "title":"Categoria"
    },

    "tooltip":[
    {
      "field": "material_ou_servico",
      "type": "nominal",
      "title": "Tipo"
    },
    {
        "aggregate":"count",
        "field": "material_ou_servico",
        "type": "nominal",
        "title": "Valor Total"
    }
   ]   
  },

})
)}

function _6(md){return(
md`# 2 - Valor total de serviços e materiais requisitados pelo governo
O balanço financeiro reflete a dominância do setor de serviços também no orçamento. Os dados econômicos demonstram que a administração pública destinou um montante significativamente maior para essa categoria, gerando um gasto 50% superior em serviços comparado ao total investido em materiais.`
)}

function _view2(embed){return(
embed({
  "$schema" : "https://vega.github.io/schema/vega-lite/v5.json",
  "title" : "Contratações de Serviços e materiais pelo governo",
  "data":{
    
    "url": "https://raw.githubusercontent.com/DerikVoid/Projeto-metadado_Gov/refs/heads/main/dadosGOV_tratados.csv",
      "format":{
        "type" : "csv"
      }
    
  },
  
 "width": 300,
 "height": 300,
  
  "mark": {
    "type": "bar",
  },

  "encoding": {

    "x": {
      "aggregate":"sum",
      "field": "valor_total",
      "type": "quantitative"
    },

    "y": {
      "field": "material_ou_servico",
      "type": "nominal"
    },

    "tooltip":[
    {
      "field": "material_ou_servico",
      "type": "nominal",
      "title": "Categoria"
    },
    {
        "aggregate":"sum",
        "field": "valor_total",
        "type": "quantitative",
        "title": "Valor Total"
    }
   ]   
  },

})
)}

function _8(md){return(
md`# 3 - Situações de compras requisitadas pelo Governo
O gráfico demonstra a quantidade de contratações realizadas pelo governo de acordo com a situação de cada processo. Observa-se que a maior parte das compras foi homologada, indicando processos concluídos com sucesso. Já uma quantidade menor aparece como fracassada, enquanto poucos processos ainda estão em andamento. Dessa forma, o gráfico permite analisar rapidamente o status geral das contratações públicas.`
)}

function _view3(embed){return(
embed({
  "$schema" : "https://vega.github.io/schema/vega-lite/v5.json",
  "title" : "Contratações de Serviços e materiais pelo governo",
  "data":{
    
    "url": "https://raw.githubusercontent.com/DerikVoid/Projeto-metadado_Gov/refs/heads/main/dadosGOV_tratados.csv",
      "format":{
        "type" : "csv",
        }
      },
  
 "width": 600,
 "height": 300,
  
  "mark": {
    "type": "bar"
  },

  "encoding": {

    "x": {
      "field":"situacao_compra_item_nome",
      "type":"nominal",
      "title":"Categoria"
    },

    "y": {
      "aggregate":"count",
      "type":"quantitative",
      "title":"Quantidade de compras"
    },

    "color":{
      "field":"data_resultado",
      "type":"ordinal",
      "title":"Ano"
    },

    "tooltip":[
      {
      "aggregate":"count",
      "type":"quantitative",
      "title":"Quantidade"
    } 
   ]   
  }
})
)}

function _10(md){return(
md`# 4 - Empresas em que o Governo mais comprou
O gráfico demonstra a quantidade de requisições realizadas pelo governo para cada fornecedor, destacando o ranking dos parceiros mais acionados. Observa-se uma forte concentração em apenas três empresas líderes, que acumulam o maior volume de contratos. Já a grande maioria dos fornecedores aparece na faixa mínima, com apenas uma ou duas requisições. Dessa forma, o gráfico permite analisar rapidamente a distribuição e a dependência dos serviços públicos em relação aos principais fornecedores.são das demandas.`
)}

function _view4(embed){return(
embed({
  "$schema" : "https://vega.github.io/schema/vega-lite/v5.json",
  "title" : "Contratações de Serviços e materiais pelo governo",
  "data":{
    
    "url": "https://raw.githubusercontent.com/DerikVoid/Projeto-metadado_Gov/refs/heads/main/dadosGOV_tratados.csv",
      "format":{
        "type" : "csv",
        }
      },
  
 "width": 600,
 "height": 300,
  
  "mark": {
    "type": "bar"
  },

  "encoding": {

    "x": {
      "field":"nome_fornecedor",
      "type":"nominal",
      "title":"Empresas"
    },

    "y": {
      "aggregate":"count",
      "type":"quantitative",
      "title":"Quantidade de vezes requisitada"
    },

     "color":{
      "field":"nome_fornecedor",
      "type":"nominal",
      "title":"Empresas"
    },

    "tooltip":[{
      "aggregate":"count",
      "type":"quantitative",
      "title":"Contratações"
    }]   
  }
})
)}

function _12(md){return(
md`# 5 - Serviços e produtos mais comprados pelo Governo
O gráfico apresenta o ranking dos 15 produtos e serviços mais contratados pela administração pública com base no volume absoluto de processos. Nota-se uma forte predominância de demandas voltadas ao setor de comunicação visual, serviços gráficos e papelaria corporativa, com destaque para a confecção de impressos, selos e sacolas personalizadas liderando as ocorrências. Essa distribuição evidencia como os materiais de suporte logístico, divulgação e identidade institucional representam compras repetitivas e de alta rotatividade na máquina pública, demandando atenção contínua para o ganho de escala e eficiência nas atas de registro de preços.`
)}

function _view5(embed){return(
embed({
  "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
  "title": "Contratações de Serviços e materiais pelo governo",
  "data": {
    "url": "https://raw.githubusercontent.com/DerikVoid/Projeto-metadado_Gov/refs/heads/main/dadosGOV_tratados.csv",
    "format": {"type": "csv"}
  },
  "width": 700,
  "height": 400,
  
  "transform": [
    {
      "aggregate": [{"op": "count", "as": "quantidade"}],
      "groupby": ["descricao_resumida"]
    },
    {
      "window": [{"op": "rank", "as": "ranking"}],
      "sort": [{"field": "quantidade", "order": "descending"}]
    },
    {
      "filter": "datum.ranking <= 15"
    }
  ],
  
  "mark": "bar",
  "encoding": {
    "y": {
      "field": "descricao_resumida",
      "type": "nominal",
      "title": "Produto",
      "sort": "-x"
    },
    "x": {
      "field": "quantidade",
      "type": "quantitative",
      "title": "Quantidade de Contratações"
    },
    "color": {
      "field": "quantidade",
      "type": "quantitative",
      "legend": null,
      "scale": {"scheme": "accent"}
    }, 
    "tooltip": [
      {
        "field": "quantidade", 
        "type": "quantitative",
        "title": "Contratações"
      }
    ]
  }
})
)}

function _14(md){return(
md`# 6 - Qual ano teve mais compras e sua evolução por tempo
O gráfico de dispersão temporal revela que as contratações do governo operam em ritmo cadenciado (bolhas escuras menores), mas sofrem picos maciços de concentração. O ano de 2026 concentra o maior volume de compras de todo o histórico, impulsionado por um evento extraordinário em abril de 2026 (bolha amarela gigante), onde as aquisições explodiram e atingiram a marca de 100 contratações acumuladas em um curto período.
`
)}

function _view6(embed){return(
embed({
  "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
  "title": "Linha do Tempo: Concentração e Picos de Contratações",
  "data": {
    "url": "https://raw.githubusercontent.com/DerikVoid/Projeto-metadado_Gov/refs/heads/main/dadosGOV_tratados.csv",
    "format": {"type": "csv"}
  },
  "width": 700,
  "height": 250, 
  
  "transform": [
    {
      "aggregate": [{"op": "count", "as": "compras"}],
      "groupby": ["data_resultado"]
    }
  ],
  
  "mark": {
    "type": "circle", 
    "opacity": 0.8,
    "stroke": "#fff",
    "strokeWidth": 1
  },
  
  "encoding": {
    "x": {
      "field": "data_resultado",
      "type": "temporal",
      "title": "Linha do Tempo (Data da Compra)"
    },
    "size": {
      "field": "compras",
      "type": "quantitative",
      "title": "Volume de Compras",
      "scale": {"range":[50, 4000]} 
    },
    "color": {
      "field": "compras",
      "type": "quantitative",
      "title": "Intensidade",
      "scale": {"scheme": "magma"} 
    },
    "tooltip": [
      {
        "field": "data_resultado",
        "type": "temporal",
        "title": "Data"
      },
      {
        "field": "compras",
        "type": "quantitative",
        "title": "Total de Contratações"
      }
    ]
  }
})
)}

function _16(md){return(
md`# 7 - Comparativo entre Valor Unitário Estimado e Valor Total das Compras

O gráfico demonstra que enquanto o preço unitário planejado (\`valor_unitario_estimado\`) permanece baixo e linear próximo ao zero, o gasto executado (\`valor_total\`) sofre flutuações e saltos massivos devido ao grande volume de itens adquiridos por contrato. Esse comportamento fica evidente no périodo de estabilidade de R$ 150.000,00 entre fevereiro e abril, seguido por uma disparada rigorosa logo após o dia 19 de abril, onde o acúmulo de contratações atinge o pico histórico do período ao ultrapassar a marca dos R$ 800.000,00.`
)}

function _view7(embed){return(
embed({
  "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
  "title": "Linha do Tempo: Concentração e Picos de Contratações",
  "data": {
    "url": "https://raw.githubusercontent.com/DerikVoid/Projeto-metadado_Gov/refs/heads/main/dadosGOV_tratados.csv",
    "format": {"type": "csv"}
  },
  
  "width": 700,
  "height": 250, 

  "transform": [
    {
      // Ele realiza a renomeação das colunas e uma mudança na estrutura desta
      "fold":["valor_unitario_estimado", "valor_total"],
      "as": ["tipo_valor", "dinheiro"]
    },
    {
      //Realiza o agrupamento das colunas separando para cada ano respectivo o tipo de valor deste(estimado ou      total).
      "aggregate":[{"op":"sum", "field":"dinheiro", "as":"dinheiro_total"}],
      "groupby":["data_resultado", "tipo_valor"]
    }  
  ],

  "mark":"line",

  "encoding":{
    "x":{
      "field":"data_resultado",
      "type":"temporal",
      "title":"Data"
    },
   "y":{
      "field":"dinheiro_total",
      "type":"quantitative",
      "title":"Valor total da compra"
   },

   "color":{
      "field":"tipo_valor",
      "type":"nominal",
      "title":"Tipo de valor",
      "scale":{"scheme": "set1"}
   },
  "tooltip": [
    {
      "field": "data_resultado",
      "type": "temporal",
      "title": "Data"
    },
    {
      "field": "tipo_valor",
      "type": "nominal",
      "title": "Categoria"
    },
    {
      "field":"dinheiro_total",
      "type":"quantitative",
      "title":"Valor total em compras",
      "format": ",.2f"
    }
    ]
  } 
})
)}

function _18(md){return(
md`# 8 - Critérios de Julgamento mais Usados nas Compras Públicas
O gráfico de barras verticais aponta uma forte predominância do critério de "Menor preço" como a métrica principal para a escolha de fornecedores nos processos licitatórios registrados. Essa concentração evidencia que a administração pública prioriza a economia direta de recursos e a competitividade por custos na maior parte de suas aquisições, deixando formatos alternativos de julgamento em segundo plano ou categorizados como não aplicáveis para os itens analisados.`
)}

function _view8(embed){return(
embed({
  "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
  "title": "Critérios de Julgamento Mais Utilizados nas Compras Públicas",
  "data": {
    "url": "https://raw.githubusercontent.com/DerikVoid/Projeto-metadado_Gov/refs/heads/main/dadosGOV_tratados.csv",
    "format": {"type": "csv"}
  },
  "width": 600,
  "height": 300,
  
  "transform": [
    {
      "aggregate": [{"op": "count", "as": "quantidade"}],
      "groupby": ["criterio_julgamento_nome"]
    }
  ],
  
  "mark": {
    "type": "bar",
  },
  
  "encoding": {
    "x": {
      "field": "criterio_julgamento_nome", 
      "type": "nominal",
      "title": "Critério de Julgamento",
      //não se aplica se refere as compras que foram compradas de form direta pelo governo sem necessidade de ter alguma pesquisa de mercado
    },
    "y": {
      "field": "quantidade",
      "type": "quantitative",
      "title": "Quantidade de Itens"
    },
    "tooltip": [
      {
        "field": "criterio_julgamento_nome", 
        "type": "nominal", 
        "title": "Critério"
      },
      {"field": "quantidade",
       "type": "quantitative", 
       "title": "Total de Itens"
      }
    ]
  }
})
)}

function _20(md){return(
md`# 9 - Análise do Uso de Benefícios e Incentivos para Empresas
O gráfico de barras empilhadas evidencia a aplicação de políticas de fomento econômico nas contratações públicas, destacando a relevância da "Participação exclusiva para ME/EPP" e revelando como esses incentivos se distribuem entre a aquisição de materiais e a prestação de serviços. Essa visualização combinada comprova o cumprimento das diretrizes legais de proteção às microempresas e empresas de pequeno porte em ambas as categorias de compra, permitindo monitorar onde os benefícios governamentais estão sendo mais efetivos e quais setores ainda operam predominantemente sob ampla concorrência ou sem incentivos específicos.`
)}

function _view9(embed){return(
embed({
  "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
  "title": "Uso de Benefícios e Incentivos por Tipo de Contratação",
  "data": {
    "url": "https://raw.githubusercontent.com/DerikVoid/Projeto-metadado_Gov/refs/heads/main/dadosGOV_tratados.csv",
    "format": {"type": "csv"}
  },
  "width": 500,
  "height": 250,
  
  "transform": [
    {
      // Mudança de nome para algo mais simples
      "calculate": "datum.tipo_beneficio_nome == 'Não se aplica' ? 'Sem Incentivo Específico' : datum.tipo_beneficio_nome",
      "as": "beneficio_limpo"
    },
    {
      // Agrupa por benefício E por tipo (Material/Serviço) para permitir o empilhamento
      "aggregate": [{"op": "count", "as": "quantidade"}],
      "groupby": ["beneficio_limpo", "material_ou_servico"]
    }
  ],
  
  "mark": {
    "type": "bar",
  },
  
  "encoding": {
    // ME e EP são micro empresas
    "y": {
      "field": "beneficio_limpo",
      "type": "nominal",
      "title": "Tipo de Benefício / Incentivo"
    },
    "x": {
      "field": "quantidade",
      "type": "quantitative",
      "title": "Quantidade de Itens"
    },
    "color": {
      "field": "material_ou_servico",
      "type": "nominal",
      "title": "Tipo de Item",
      "scale": {"scheme": "category10"} 
    },
    "tooltip": [
      {
        "field": "beneficio_limpo", 
       "type": "nominal", 
       "title": "Benefício"
      },
      {
        "field": "material_ou_servico", 
        "type": "nominal", 
        "title": "Tipo"
      },
      {
        "field": "quantidade", 
        "type": "quantitative",
        "title": "Total de Itens"
      }
    ]
  }
})
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("embed")).define("embed", ["require"], _embed);
  main.variable(observer()).define(_3);
  main.variable(observer()).define(["md"], _4);
  main.variable(observer("viewof view1")).define("viewof view1", ["embed"], _view1);
  main.variable(observer("view1")).define("view1", ["Generators", "viewof view1"], (G, _) => G.input(_));
  main.variable(observer()).define(["md"], _6);
  main.variable(observer("viewof view2")).define("viewof view2", ["embed"], _view2);
  main.variable(observer("view2")).define("view2", ["Generators", "viewof view2"], (G, _) => G.input(_));
  main.variable(observer()).define(["md"], _8);
  main.variable(observer("viewof view3")).define("viewof view3", ["embed"], _view3);
  main.variable(observer("view3")).define("view3", ["Generators", "viewof view3"], (G, _) => G.input(_));
  main.variable(observer()).define(["md"], _10);
  main.variable(observer("viewof view4")).define("viewof view4", ["embed"], _view4);
  main.variable(observer("view4")).define("view4", ["Generators", "viewof view4"], (G, _) => G.input(_));
  main.variable(observer()).define(["md"], _12);
  main.variable(observer("viewof view5")).define("viewof view5", ["embed"], _view5);
  main.variable(observer("view5")).define("view5", ["Generators", "viewof view5"], (G, _) => G.input(_));
  main.variable(observer()).define(["md"], _14);
  main.variable(observer("viewof view6")).define("viewof view6", ["embed"], _view6);
  main.variable(observer("view6")).define("view6", ["Generators", "viewof view6"], (G, _) => G.input(_));
  main.variable(observer()).define(["md"], _16);
  main.variable(observer("viewof view7")).define("viewof view7", ["embed"], _view7);
  main.variable(observer("view7")).define("view7", ["Generators", "viewof view7"], (G, _) => G.input(_));
  main.variable(observer()).define(["md"], _18);
  main.variable(observer("viewof view8")).define("viewof view8", ["embed"], _view8);
  main.variable(observer("view8")).define("view8", ["Generators", "viewof view8"], (G, _) => G.input(_));
  main.variable(observer()).define(["md"], _20);
  main.variable(observer("viewof view9")).define("viewof view9", ["embed"], _view9);
  main.variable(observer("view9")).define("view9", ["Generators", "viewof view9"], (G, _) => G.input(_));
  return main;
}
